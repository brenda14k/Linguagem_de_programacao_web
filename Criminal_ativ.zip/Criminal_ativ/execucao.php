<?php

require_once("Modelo/Serie.php");

$mentalista = [
    new Serie("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkzEY3BH1L4XpgedttLRYMi5dS-2rZHIe5tw&s", "Patrick Jane"),
    new Serie("https://preview.redd.it/june-19th-2025-happy-birthday-robin-aka-teresa-lisbon-v0-dyn1gowu5v7f1.jpg?width=640&crop=smart&auto=webp&s=73c1fdd95e36c9fa922fcfdc1dd4fa57193dedcb", "Teresa Lisbon"),
    new Serie("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFtyKIxqBHCADWI9KHQHrcid92I293vxd9dA&s", "Grace Van Pelt")
];


$csiMiami = [
    new Serie("https://i2.wp.com/images1.fanpop.com/images/photos/2600000/CSI-Miami-7x09-Power-Trip-Promotional-Photo-csi-miami-2615356-1727-2560.jpg", "Horatio Caine"),
    new Serie("https://static.wikia.nocookie.net/beautybydaysi/images/1/14/Eric_Delko.png", "Eric Delko"),
    new Serie("https://static.wikia.nocookie.net/beautybydaysi/images/a/a5/Calleigh_Duquesne.png", "Calleigh Duquesne")
];


$csiNY = [
    new Serie("https://static.wikia.nocookie.net/csi/images/f/fb/Taylor.jpg", "Mac Taylor"),
    new Serie("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTW5kZg9vFSt5NzCZquZ08A5q3tnY62HxMnEQ&s", "Stela Bonasera"),
    new Serie("https://m.media-amazon.com/images/M/MV5BYzJjM2M3ZDMtMDhhMy00MGIxLTljMTktMDliZGVlNjhjYjI5XkEyXkFqcGc@._V1_.jpg", "Lindsey Monroe")
];


$bones = [
    new Serie("https://upload.wikimedia.org/wikipedia/en/3/35/Seeleybobo.JPG", "Seeley Booth"),
    new Serie("https://upload.wikimedia.org/wikipedia/en/3/30/Temperance_Brennan.jpg", "Temperance Bones Brennan"),
    new Serie("https://static.wikia.nocookie.net/bonesfanon/images/e/e8/Angela.jpg", "Angela Montenegro")
];
?>



<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="style.css">
<title>Séries Criminais</title>
</head>
<body>

<?php

function desenhaBotao($titulo, $Serie){
    echo '<div class="dropdown">';
    echo '<button class="dropbtn">'.$titulo.'</button>';
    echo '<div class="dropText">';
    
    foreach($Serie as $S){
        echo '<span><img src="'.$S->getLinkImg().'" width="37" height="37"> '.$S->getNome().'</span>';
    }

    echo '</div>'; 
    echo '</div>'; 
}


desenhaBotao("The Mentalist", $mentalista);
desenhaBotao("CSI Miami", $csiMiami);
desenhaBotao("CSI New York", $csiNY);
desenhaBotao("Bones", $bones);
?>

</body>
</html>