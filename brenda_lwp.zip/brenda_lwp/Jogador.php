<?php
function criarLinha($numero, $nome,$cor) {
    echo "<tr style='background-color:$cor;'>";
    echo "<td>$numero</td>";
    echo "<td>$nome</td>";
    echo "</tr>";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Seleção Brasileira</title>

<style>
table {
  border-collapse: collapse;
  width: 60%;
}

table, th, td {
  border: 1px solid black;
}

th, td {
  padding: 8px;
}
</style>

</head>
<body>

    <table>
    <tr>
        <th>Número</th>
        <th>Nome</th>
    </tr>
<?php
//crie o array
    $jogadores = [
        [2, "Jorginho"],
        [13, "Aldair"],
        [15, "Márcio Santos"],
        [6, "Branco"],
        [5, "Mauro Silva"],
        [8, "Dunga"],
        [17, "Marzinho"],
        [9, "Zinho"],
        [11, "Romário"],
        [7, "Bebeto"]
    ];

    $cores = ["yellow", "green"]; 
$indice = 0;// usado para contar qual linha receba as core

    foreach ($jogadores as $jogador) {
        $cor = $cores[$indice % 2];// divide por 2 se a linha for [0] a cor será yellow  e se fo [1] a cor será verde e se o resto dar 0 ou 1 muda a cor 
    criarLinha($jogador[0], $jogador[1], $cor);
    $indice++;
}
    ?>
    </table>

</body>
</html>
